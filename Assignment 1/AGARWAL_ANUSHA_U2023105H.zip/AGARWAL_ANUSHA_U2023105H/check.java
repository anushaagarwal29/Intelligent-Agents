public class check {
    public static void main(String[] args){
    System. out. println("Current JVM version - " + System. getProperty("java.version"));
    }
}